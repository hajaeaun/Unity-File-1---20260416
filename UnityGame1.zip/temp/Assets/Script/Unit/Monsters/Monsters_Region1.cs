using UnityEngine;
using System.Collections.Generic;
using System;

namespace HaJaeJun
{
    public class Monsters_Region1 : MonoBehaviour
    {

        void Start()
        {

        }
    }
}
