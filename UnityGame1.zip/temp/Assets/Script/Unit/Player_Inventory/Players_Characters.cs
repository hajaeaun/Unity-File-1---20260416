using UnityEngine;
using System.Collections.Generic;
using System;

namespace HaJaeJun
{
    public class Players_Characters : MonoBehaviour
    {
        public PlayableCharacters baseData;
        public int level;
        public int currentHp;

        public Players_Characters(PlayableCharacters baseData, int level)
        {

        }
    }
}
