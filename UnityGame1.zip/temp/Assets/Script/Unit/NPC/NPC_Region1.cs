using UnityEngine;
using System.Collections.Generic;
using System;

namespace HaJaeJun
{
    public class NPC_Region1 : MonoBehaviour
    {


        public void Talk()
        {

        }
    }
}
