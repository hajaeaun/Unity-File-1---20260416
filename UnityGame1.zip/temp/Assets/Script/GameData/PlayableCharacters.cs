using UnityEngine;
using System.Collections.Generic;
using System;


namespace HaJaeJun
{
    public class PlayableCharacters : MonoBehaviour
    {
        public string Name;
        public int Level;
        public int HP;
        public int Att;
        public int Def;
    }

    public class Castoreese : PlayableCharacters
    {
        public Castoreese()
        {
            Name = "ī���丮��";
            Level = 1;
            HP = 2500;
            Att = 150;
            Def = 50;
        }
    }

     
    

}
