using UnityEngine;
using System.Collections.Generic;
using System;

namespace HaJaeJun
{
    public static class Data_Index_Inform
    {

    }
}
