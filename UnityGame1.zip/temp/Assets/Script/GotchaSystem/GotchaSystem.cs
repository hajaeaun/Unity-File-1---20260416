using UnityEngine;
using System;
using System.Collections.Generic;
using HaJaeJun;

public class GotchaSystem : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created


    static public PlayableCharacters GetCharac1st(Type type) 
    {
        PlayableCharacters c = (PlayableCharacters)Activator.CreateInstance(type);
        return c;
    }
}
