using UnityEngine;
using System.Collections.Generic;
using System;

namespace HaJaeJun
{
    public class TurnManager : MonoBehaviour
    {

    }
}
