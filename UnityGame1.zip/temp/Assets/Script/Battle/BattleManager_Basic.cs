using UnityEngine;
using System.Collections.Generic;
using System;

namespace HaJaeJun
{
    public class BattleManager_Basic : MonoBehaviour
    {

    }
}
