using UnityEngine;
using System.Collections.Generic;
using System;

namespace HaJaeJun
{
    public class NewMonoBehaviourScript : MonoBehaviour
    {
        // Start is called once before the first execution of Update after the MonoBehaviour is created
        void Start()
        {

        }

        // Update is called once per frame
        void Update()
        {

        }
    }
}
