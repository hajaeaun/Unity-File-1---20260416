using UnityEngine;

public class GameManager : MonoBehaviour
{
    [SerializeField] Rigidbody Rb;
    public float speed = 10f;
    public float JumpPower= 300f;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
