using System;
using UnityEngine;
using UnityEngine.InputSystem;
public class Player1 : MonoBehaviour
{
    Vector2 Vec2 = Vector2.zero;

    [SerializeField] GameManager GM;
    [SerializeField] Rigidbody Rb;

    [SerializeField] private float speed = 10f;
    [SerializeField] private float JumpPower = 300f;

    private bool CanJump = false;

    RaycastHit Hit;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        Debug.Log("GameStart");
    }

    // Update is called once per frame
    void Update()
    {
        CreateDrawRay();
        Move();
        isJump();
    }
    void FixedUpdate()
    {

    }
    void OnMove(InputValue value)
    {
        Vec2 = value.Get<Vector2>();
    }
    void Move()
    {
        //Debug.Log("Move");
        transform.Translate(new Vector3(Vec2.x, 0f, Vec2.y) * Time.deltaTime * speed);

    }
    void OnJump()
    {
        //Debug.Log("OnJump");
       
        if (CanJump)
        {
            Rb.AddForce(new Vector3(0f, JumpPower, 0f));
        }
    }
    void CreateDrawRay()
    {
        //Debug.Log("DrawRay");
        Debug.DrawRay(transform.position, Vector3.down * 1.5f, Color.red, 0.1f);
    }
    void RayCast()
    {
        Physics.Raycast(transform.position, Vector3.down, out Hit, 1.05f);
    }
    void isJump()
    {
        //Debug.Log("isJump");

        CanJump = false;

        if (Physics.Raycast(transform.position, Vector3.down, out Hit, 1.05f))
        {
            if (Hit.transform.name == "BG")
            {
                //Debug.Log("HitSuccess");
                CanJump = true;
            }
        }
    }
}
